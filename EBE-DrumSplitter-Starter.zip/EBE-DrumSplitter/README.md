# E.B.E.'s Drum Splitter

Starter iOS app for importing a song and separating drum components such as kick, snare, hi-hat/cymbals, and other percussion.

## Current starter build
- SwiftUI iOS interface
- Audio-file importer
- Track information display
- Stem selection controls
- Separation service interface ready for a Core ML/audio-separation model
- Export/share scaffolding

## Important
This starter project does **not yet include a trained drum-separation ML model**. The included `DrumSeparationService` currently creates placeholder output copies so the complete app flow can be built and tested. A compatible Core ML model (or a server-backed separation engine) is the next major component required for real kick/snare/hat isolation.

## Build
1. On a Mac with Xcode, create/open an iOS SwiftUI project named `EBEDrumSplitter`.
2. Add the Swift files in the `EBEDrumSplitter` folder to the app target.
3. Set the deployment target to iOS 17 or later.
4. Build and run on iPhone or Simulator.

## Product direction
The intended commercial version can support song import, drum stem separation, preview/mute/solo, WAV export, and App Store distribution.
